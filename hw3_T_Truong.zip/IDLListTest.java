import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IDLListTest {
    IDLList<Integer> myList = new IDLList<>();

    @BeforeEach
    private void prepareBasicData() {  //the default list that is used to test is: 0123
        myList = new IDLList<>();
        myList.add(3);
        myList.add(2);
        myList.add(1);
        myList.add(0);
    }

    @Test
    void addAtIndex() {
        boolean addingResult = myList.addAtIndex(2, 9);
        assertTrue(addingResult);
        assertEquals("01923", myList.toString());
    }

    @Test
    void addAtOutOfIndex() {
        boolean addingResult = myList.addAtIndex(5, 9);
        assertFalse(addingResult);
    }

    @Test
    void add() {
        myList.add(0);
        assertEquals("00123", myList.toString());
    }

    @Test
    void addOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        boolean result = newList.add(4);
        assertTrue(result);
        assertEquals("4", newList.toString());
    }

    @Test
    void append() {
        myList.append(4);
        assertEquals("01234", myList.toString());
    }

    @Test
    void appendOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        boolean result = newList.append(4);
        assertTrue(result);
        assertEquals("4", newList.toString());
    }

    @Test
    void get() {
        int value = myList.get(2);
        assertEquals (2, 2);
    }

    @Test
    void getOutOfIndex() {
        assertThrows(IndexOutOfBoundsException.class, () -> myList.get(5));
    }

    @Test
    void getHead() {
        int value = myList.getHead();
        assertEquals(0,0);
    }

    @Test
    void getHeadOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        assertNull(newList.getHead());
    }

    @Test
    void getLast() {
        int value = myList.getLast();
        assertEquals(3,3);
    }

    @Test
    void getLastOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        assertNull(newList.getLast());
    }

    @Test
    void size() {
        int value = myList.size();
        assertEquals(4,value);
    }

    @Test
    void remove() {
        int value = myList.remove();
        assertEquals(0,value);
    }

    @Test
    void removeOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        assertNull(newList.remove());
    }

    @Test
    void removeLast() {
        int value = myList.removeLast();
        assertEquals(3,value);
        assertEquals("012", myList.toString());
    }

    @Test
    void removeLastOnEmptyList() {
        IDLList<Integer> newList = new IDLList<>();
        assertNull(newList.removeLast());
    }

    @Test
    void removeAt() {
        int value = myList.removeAt(2);
        assertEquals(2, value);
        assertEquals("013", myList.toString());
    }

    @Test
    void removeAtOutOfIndex() {
        assertThrows(IndexOutOfBoundsException.class, () -> myList.removeAt(5));
    }

    @Test
    void booleanRemove() {
        assertTrue(myList.remove(2));
        assertEquals("013", myList.toString());
    }

    @Test
    void booleanRemoveElemIsNotInList() {
        assertFalse(myList.remove(5));
    }

    @Test
    void testToString() {
        assertEquals("0123", myList.toString());
    }
}