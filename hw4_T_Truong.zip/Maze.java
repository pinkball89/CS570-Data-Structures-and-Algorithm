/**
 * 2021F CS 570-B. Homework Assignment 4.
 * The aim of this assignment is to use recursion and backtracking to find a path through a maze.
 * If you are attempting to walk through the maze, you will probably walk down a path as far as you can go.
 * Eventually, you will reach your destination, or you won't be able to go any further.
 * If you can't go to any further, you will need to consider alternative paths.
 * Therefore, we need to be able to systematically perform trial and error search. Backtracking is a way for doing just this.
 * It is a systematic, non-repetitive approach to trying alternative paths and eliminating them if they don't work.
 * Recursion allows you to implement backtracking in a relatively straightforward manner.
 * Each activation frame is used to remember the choice that was made at that particular decision point.
 * After returning from a recursive call, you can perform other recursive calls to try out different paths.
 *
 * CWID: 20007427
 * @Truong
 * @Date 11/02/2021
 */

import java.util.*;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Stack;

// Class Maze: This is the class which you have to modify by implementing your search algorithm.
// It has a private field "maze" of type "TwoDimGrid", where the two-dimensional grid is stored.
// The method you have to implement is "public boolean findMazePath(int x, int y)".
// Also, you shall be asked to implement some variations of this algorithm, each of which will result in a new method.
// The details of these methods are described in Sec. 3 together with a description of other methods of the class that you will need.

public class Maze implements GridColors {
    /** The maze */
    private TwoDimGrid maze;

    public Maze(TwoDimGrid m) {
        maze = m;
    }

    /** Wrapper method. */
    public boolean findMazePath() {
        return findMazePath(0, 0); // (0, 0) is the start point.
    }

    /**
     * Attempts to find a path through point (x, y).
     * @pre Possible path cells are in BACKGROUND color;
     *      barrier cells are in ABNORMAL color.
     * @post If a path is found, all cells on it are set to the
     *       PATH color; all cells that were visited but are
     *       not on the path are in the TEMPORARY color.
     * @param x The x-coordinate of current point
     * @param y The y-coordinate of current point
     * @return If a path through (x, y) is found, true;
     *         otherwise, false
     */

    // COMPLETE HERE FOR PROBLEM 1: implement a recursive algorithm public boolean findMazePath(int x, int y) that returns true if a path is found

    public boolean findMazePath(int x, int y) {
        if (x < 0 || y < 0 || x >= maze.getNCols() || y >= maze.getNRows() || maze.getColor(x, y) == TEMPORARY || maze.getColor(x, y) == BACKGROUND)
            return false;
        else if (x == maze.getNCols() - 1 && y == maze.getNRows() -1) {
            maze.recolor(x, y, PATH);
            return true;
        }
        else if (maze.getColor(x, y) == GridColors.NON_BACKGROUND) {
            maze.recolor(x, y, TEMPORARY);
            if (this.findMazePath(x+1, y) || this.findMazePath(x-1, y) || this.findMazePath(x, y+1) || this.findMazePath(x, y-1)) {
                maze.recolor(x, y, PATH);
                return true;
            }
        }
        return this.findMazePath(x+1,y) || this.findMazePath(x-1,y)  || this.findMazePath(x,y+1) || this.findMazePath(x,y-1);
    }

    // ADD METHOD FOR PROBLEM 2 HERE:
    // implement a recursive algorithm
    // public ArrayList<ArrayList<PairInt>> findAllMAzePaths(int x, int y) by modifying the solution of Problem 1
    // so that a list of all the solutions to the maze is returned. Each solution may be represented as a list of coordinates.
    // If there are no solutions, then the resulting list should have the empty list as only element.

    public ArrayList <ArrayList<PairInt>> findAllMazePaths (int x, int y) {
        ArrayList <ArrayList <PairInt>> result = new ArrayList<>();
        Stack <PairInt> trace = new Stack<>();
        findMazePathStackBased(0, 0, result, trace);
        if(result.size() == 0) {
            ArrayList<PairInt> temp = new ArrayList<PairInt>();
            result.add(temp);
        }
        return result;
    }

    public void findMazePathStackBased(int x, int y, ArrayList<ArrayList<PairInt>> result, Stack<PairInt> trace) {
        if(!(x >= 0 && x < maze.getNCols() && y >= 0 && y < maze.getNRows())) {
            return;
        } else if(maze.getColor(x,y) != NON_BACKGROUND) {
            return;
        }
        else if(x == maze.getNCols()-1 && y == maze.getNRows()-1) {
            trace.push(new PairInt(x,y));
            ArrayList<PairInt> list = new ArrayList<PairInt>();
            list.addAll(trace);
            result.add(list);
            trace.clear();
        }
        else {
            trace.push(new PairInt(x,y));
            maze.recolor(x, y,PATH);
            findMazePathStackBased(x+1, y, result, (Stack<PairInt>)trace.clone());
            findMazePathStackBased(x, y+1, result, (Stack<PairInt>)trace.clone());
            findMazePathStackBased(x-1, y, result, (Stack<PairInt>)trace.clone());
            findMazePathStackBased(x, y-1, result, (Stack<PairInt>)trace.clone());
            maze.recolor(x, y, NON_BACKGROUND);
        }
    }


    // ADD METHOD FOR PROBLEM 3 HERE: adapt boolean Maze.findMazePath() so that it returns the shortest path in the list of paths.
    // The resulting method should be called public ArrayList<PairInt> findMazePathMin(int x, int y)

    public ArrayList<PairInt> findMazePathMin(int x, int y){
        ArrayList<ArrayList<PairInt>> result = findAllMazePaths(x, y);
        int intArray[] = new int[result.size()];
        for (int i = 0; i < result.size(); i++) {
            intArray[i] = result.get(i).size();
        }
        int min = intArray[0];
        int minIndex = 0;
        for (int i = 1; i < intArray.length; i++) {
            if (intArray[i] < min) {
                min = intArray[i];
                minIndex = i;
            }
        }
        return result.get(minIndex);
    }

    public void resetTemp() {
        maze.recolor(TEMPORARY, BACKGROUND);
    }

    public void restore() {
        resetTemp();
        maze.recolor(PATH, BACKGROUND);
        maze.recolor(NON_BACKGROUND, BACKGROUND);
    }
}
