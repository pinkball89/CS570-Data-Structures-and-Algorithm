/**
 * 2021F CS 570-B. Homework Assignment 4.
 * The aim of this assignment is to use recursion and backtracking to find a path through a maze.
 * If you are attempting to walk through the maze, you will probably walk down a path as far as you can go.
 * Eventually, you will reach your destination, or you won't be able to go any further.
 * If you can't go to any further, you will need to consider alternative paths.
 * Therefore, we need to be able to systematically perform trial and error search. Backtracking is a way for doing just this.
 * It is a systematic, non-repetitive approach to trying alternative paths and eliminating them if they don't work.
 * Recursion allows you to implement backtracking in a relatively straightforward manner.
 * Each activation frame is used to remember the choice that was made at that particular decision point.
 * After returning from a recursive call, you can perform other recursive calls to try out different paths.
 *
 * CWID: 20007427
 * @Truong
 * @Date 11/02/2021
 */

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;

//Class MazeTest: This class provides a graphical interface to test your algorithm. This should be the main class of your project.
// The main methods of this class:
// 1. asks you for the size of the grid,
// 2. displays an initial grid where all cells have been set to color BACKGROUND (see Fig. 19a0 which depicts a 5 by 5 grid), and
// 3. allows you to edit it in order to indicate which cells are potentially considered to be part of a path

public class MazeTest extends JFrame implements GridColors {

    // data field
    private TwoDimGrid theGrid; // a 2-D grid of buttons

    //Reads data file and defines array bitMap to match data file
    public static void main(String[] args) {
        try {
            if (args.length < 1) {
                // no file name given
                String reply =
                        JOptionPane.showInputDialog("Enter number of rows");
                int nRows = Integer.parseInt(reply);
                reply =
                        JOptionPane.showInputDialog("Enter number of columns");
                int nCols = Integer.parseInt(reply);
                TwoDimGrid aGrid = new TwoDimGrid(nRows, nCols);
                new MazeTest(aGrid);
            } else {
                // Create array bitMap from a data file
                BufferedReader br =
                        new BufferedReader(new FileReader(args[0]));

                // Read each data line (a string) into
                // gridArrayList. Each element is a char array.
                ArrayList<char[]> gridArrayList = new ArrayList<char[]>();
                String line;
                while ((line = br.readLine()) != null) {
                    char[] row = line.toCharArray();
                    gridArrayList.add(row);
                }

                // bitMap is a 2-D array based on data in gridArrayList
                char[][] bitMap =
                        gridArrayList.toArray(new char[gridArrayList.size()][]);
                int nRows = bitMap.length;
                int nCols = bitMap[0].length;

                // create a new TwoDimGrid and recolor it based on bitMap
                TwoDimGrid aGrid = new TwoDimGrid(nRows, nCols);
                aGrid.recolor(bitMap, NON_BACKGROUND);
                new MazeTest(aGrid);
            }
        } catch (Exception ex) {
            System.err.println("Exception " + ex);
            ex.printStackTrace();
            System.exit(1);
        }
    }

    // Builds the GUI
    private MazeTest(TwoDimGrid aGrid) {
        theGrid = aGrid;
        getContentPane().add(aGrid, BorderLayout.CENTER);
        //       Blob aBlob = new Blob(aGrid);
        JTextArea instruct = new JTextArea(2, 20);
        instruct.setText("Toggle a button to change its color"
                + "\nPress SOLVE when ready");
        getContentPane().add(instruct, BorderLayout.NORTH);
        JButton solveButton = new JButton("SOLVE");
        solveButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                solve();
            }
        });
        JButton resetButton = new JButton("RESET");
        resetButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                (new Maze(theGrid)).restore();
            }
        });
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(solveButton);
        bottomPanel.add(resetButton);
        getContentPane().add(bottomPanel, BorderLayout.SOUTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack();
        setVisible(true);
    }

    public void solve() {
        Maze m = new Maze(theGrid);
        boolean found = m.findMazePath();
        if (found) {
            JOptionPane.showMessageDialog(null, "Success - reset maze and try again");
        } else {
            JOptionPane.showMessageDialog(null, "No path - reset maze and try again");
        }

        //Uncomment this to test findAllMazePaths
        ArrayList<ArrayList<PairInt>> res = m.findAllMazePaths(0,0);
        JOptionPane.showMessageDialog(null, res);


        //Uncomment this to test findMazePathMin
        ArrayList<PairInt> p = m.findMazePathMin(0, 0);
        JOptionPane.showMessageDialog(null, p);

    }
}

