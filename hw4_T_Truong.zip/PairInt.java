/**
 * 2021F CS 570-B. Homework Assignment 4.
 * The aim of this assignment is to use recursion and backtracking to find a path through a maze.
 * If you are attempting to walk through the maze, you will probably walk down a path as far as you can go.
 * Eventually, you will reach your destination, or you won't be able to go any further.
 * If you can't go to any further, you will need to consider alternative paths.
 * Therefore, we need to be able to systematically perform trial and error search. Backtracking is a way for doing just this.
 * It is a systematic, non-repetitive approach to trying alternative paths and eliminating them if they don't work.
 * Recursion allows you to implement backtracking in a relatively straightforward manner.
 * Each activation frame is used to remember the choice that was made at that particular decision point.
 * After returning from a recursive call, you can perform other recursive calls to try out different paths.
 *
 * CWID: 20007427
 * @Truong
 * @Date 10/23/2021
 */

// Class PairInt is a class you should define and which encodes pairs of integers that represent coordinates.
// The operations it should support are described below ("copy" should return a new copy of a PairInt)

public class PairInt {
    // Data field
    private int x;
    private int y;  //(x,y) are the coordinates currently being visited

    //Constructor
    public PairInt(int x, int y) {
        this.x = x;
        this.y = y;
    }

    //Get() and Set() methods
    public int getX() { return x; };
    public int getY() { return y; };

    public void setX(int x) { this.x = x; };
    public void setY(int y) { this.y = y; };

    //equals() method
    public boolean equals(Object p) {
        if (!(p instanceof PairInt)) {
            return false;
        } else {
            PairInt pairInt = (PairInt) p;
            return this.x == pairInt.x && this.y == pairInt.y;
        }
    }


    public String toString() {

        return "[" + String.valueOf(x) + "," + String.valueOf(y)+"]";
    }

    public PairInt copy() {
        PairInt solution= new PairInt(x,y);
        return solution;

    }
}
