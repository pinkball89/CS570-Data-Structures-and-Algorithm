/**
 * 2021F CS 570-B. Homework Assignment 4.
 * The aim of this assignment is to use recursion and backtracking to find a path through a maze.
 * If you are attempting to walk through the maze, you will probably walk down a path as far as you can go.
 * Eventually, you will reach your destination, or you won't be able to go any further.
 * If you can't go to any further, you will need to consider alternative paths.
 * Therefore, we need to be able to systematically perform trial and error search. Backtracking is a way for doing just this.
 * It is a systematic, non-repetitive approach to trying alternative paths and eliminating them if they don't work.
 * Recursion allows you to implement backtracking in a relatively straightforward manner.
 * Each activation frame is used to remember the choice that was made at that particular decision point.
 * After returning from a recursive call, you can perform other recursive calls to try out different paths.
 *
 * CWID: 20007427
 * @Truong
 * @Date 10/22/2021
 */

//Interface GridColors: This interface simply assigns names to the various colors that a cell can have.

import java.awt.Color;

public interface GridColors {
    Color PATH = Color.green;
    Color BACKGROUND = Color.white;
    Color NON_BACKGROUND = Color.red;
    Color ABNORMAL = NON_BACKGROUND;
    Color TEMPORARY = Color.black;
}
